@javax.xml.bind.annotation.XmlSchema(namespace = "http://web.learn.org/")
package org.learn.web;
