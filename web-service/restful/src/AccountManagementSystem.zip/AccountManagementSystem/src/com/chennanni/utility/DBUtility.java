package com.chennanni.utility;

public class DBUtility {

}
