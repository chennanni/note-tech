package weather;

import org.springframework.web.client.RestTemplate;

public class WeatherApp {
	public static void main(String args[]) {
		String url = "http://api.openweathermap.org/data/2.5/weather?q=London,uk";
		RestTemplate restTemplate = new RestTemplate();
	    Model model = restTemplate.getForObject(url, Model.class);
	    System.out.println("Name: " + model.getName());
	}
}
