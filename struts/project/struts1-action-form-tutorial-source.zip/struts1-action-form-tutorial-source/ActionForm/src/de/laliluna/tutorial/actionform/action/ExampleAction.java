//Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.4/xslt/JavaClass.xsl

package de.laliluna.tutorial.actionform.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

import de.laliluna.tutorial.actionform.form.ExampleForm;

/** 
 * MyEclipse Struts
 * Creation date: 02-04-2005
 * 
 * XDoclet definition:
 * @struts:action path="/example" name="exampleForm" input="/form/example.jsp" scope="request" validate="true"
 */
public class ExampleAction extends Action {

	public ActionForward execute(
		ActionMapping mapping,
		ActionForm form,
		HttpServletRequest request,
		HttpServletResponse response) {
		
		//ActionForm zuweisen 
		ExampleForm exampleForm = (ExampleForm) form;
		
		//Zugriff auf Eigenschaften der ActionForm
		//Klasse innerhalb der Action Klasse
		System.out.println(exampleForm.getName());
		System.out.println(exampleForm.getAge());
		
		return mapping.findForward("showExample");
	}

}