//Created by MyEclipse Struts
// XSL source (default): platform:/plugin/com.genuitec.eclipse.cross.easystruts.eclipse_3.8.4/xslt/JavaClass.xsl

package de.laliluna.tutorial.actionform.form;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts.action.ActionError;
import org.apache.struts.action.ActionErrors;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionMapping;


/** 
 * MyEclipse Struts
 * Creation date: 02-04-2005
 * 
 * XDoclet definition:
 * @struts:form name="exampleForm"
 */
public class ExampleForm extends ActionForm {
	
	//Eigenschaften der Klasse
	private String name;
	private int age;
	
	
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	// --------------------------------------------------------- Methods

	/** 
	 * Method validate
	 * @param mapping
	 * @param request
	 * @return ActionErrors
	 */
	public ActionErrors validate(
		ActionMapping mapping,
		HttpServletRequest request) {
		
		//Instanz von ActionErrors erzeugen
		ActionErrors actionErrors = new ActionErrors();
		
		//Validierung der Eigenschaft 'name'
		if(name.length() < 3){
			actionErrors.add(ActionErrors.GLOBAL_ERROR, new ActionError("error.name"));
		}
		//Validierung der Eigenschaft 'age'
		if(age < 1){
			actionErrors.add(ActionErrors.GLOBAL_ERROR, new ActionError("error.age"));
		}
		
		//R�ckgabe der Fehler
		return actionErrors;
	}

	/** 
	 * Method reset
	 * @param mapping
	 * @param request
	 */
	public void reset(ActionMapping mapping, 
					  HttpServletRequest request) {
		
		//Initialisieren der Eigenschaften
		name = "Adam Weisshaupt";
		age = 23;
	}

}