package com.earldouglas.guicespringjc;

public class DefaultGreeter implements Greeter {

  public String getGreeting() {
    return "Hello World!";
  }
}