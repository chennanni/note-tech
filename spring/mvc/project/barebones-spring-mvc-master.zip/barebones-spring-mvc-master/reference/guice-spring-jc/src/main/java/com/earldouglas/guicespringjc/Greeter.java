package com.earldouglas.guicespringjc;

public interface Greeter {
    public String getGreeting();
}
