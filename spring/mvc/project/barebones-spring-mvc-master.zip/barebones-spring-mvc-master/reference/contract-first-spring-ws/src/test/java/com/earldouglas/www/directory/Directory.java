/**
 * Directory.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package com.earldouglas.www.directory;

public interface Directory extends java.rmi.Remote {
    public com.earldouglas.www.directory.Employee employee(com.earldouglas.www.directory.Id employeeRequest) throws java.rmi.RemoteException;
}
