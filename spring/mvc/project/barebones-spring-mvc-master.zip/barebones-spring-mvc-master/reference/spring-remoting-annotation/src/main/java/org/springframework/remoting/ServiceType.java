package org.springframework.remoting;

public enum ServiceType {
    HTTP, BURLAP, HESSIAN, RMI
}
