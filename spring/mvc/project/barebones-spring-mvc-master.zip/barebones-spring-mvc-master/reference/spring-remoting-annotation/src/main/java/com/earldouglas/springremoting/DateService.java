package com.earldouglas.springremoting;

import java.util.Date;

public interface DateService {
    public Date getDate();
}
