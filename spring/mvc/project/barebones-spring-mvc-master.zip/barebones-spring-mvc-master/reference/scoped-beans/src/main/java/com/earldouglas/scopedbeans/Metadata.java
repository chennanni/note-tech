package com.earldouglas.scopedbeans;

public interface Metadata {
    public String getDate();
}
