package com.earldouglas.dategrity;

public class TamperException extends Exception {

}
