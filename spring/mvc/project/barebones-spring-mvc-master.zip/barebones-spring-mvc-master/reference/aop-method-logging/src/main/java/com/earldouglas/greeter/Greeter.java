package com.earldouglas.greeter;

public interface Greeter {

    public String getGreeting();
}
