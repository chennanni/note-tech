package com.earldouglas.greeter;

public class SpanishGreeter implements Greeter {

	public String getGreeting() {
		return "¡Hola Mundo!";
	}
}
