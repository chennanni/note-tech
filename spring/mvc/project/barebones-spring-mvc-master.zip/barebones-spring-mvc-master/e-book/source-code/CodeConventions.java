package com.earldouglas.barebones.springmvc;

public class CodeConventions {

	public static void main(String[] arguments) {
		System.out.println("Hello World!");
	}
}
