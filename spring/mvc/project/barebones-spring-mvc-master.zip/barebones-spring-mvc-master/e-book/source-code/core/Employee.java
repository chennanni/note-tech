public class Employee {

	private Long id;
	private String name;
	private String title;

	public Edmployee() {
	}

	public Employee(Long id, String name, String title) {
		this.id = id;
		this.name = name;
		this.title = title;
	}

	// Getters and setters omitted for brevity.
}
