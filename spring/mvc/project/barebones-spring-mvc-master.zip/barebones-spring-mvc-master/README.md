# Barebones Spring MVC

Barebones Spring MVC is an e-book based on the article series I started in 2009. It is a basic overview of some of the most commonly used components of Spring MVC 3.0, and takes the reader through the development of an example Spring MVC application from scratch.

* Download the [PDF](https://github.com/JamesEarlDouglas/barebones-spring-mvc/raw/master/e-book/barebones-spring-mvc.pdf)

