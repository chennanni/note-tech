package com.marlabs.spring;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

@SuppressWarnings("deprecation")
public class WelcomeClient {

	public static void main(String[] args) {
		Resource res = new ClassPathResource("myApplicationContext.xml");
		BeanFactory factory = new XmlBeanFactory(res);

		WelcomeBean bean = (WelcomeBean) factory.getBean("id1");
		
		bean.show();

	}

}
