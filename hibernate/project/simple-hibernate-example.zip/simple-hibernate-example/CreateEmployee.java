package org.learn.demo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class CreateEmployee {
	public static void main(String[] args) {
		
		//creating configuration object
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");//populates the data of the configuration file
		
		//creating session factory object
		@SuppressWarnings("deprecation")
		SessionFactory factory = cfg.buildSessionFactory();
		
		//creating session object
		Session session=factory.openSession();
		
		//creating transaction object
		Transaction t=session.beginTransaction();
			
		Employee e1=new Employee();
		e1.setId(101);
		e1.setFirstName("Jackie");
		e1.setLastName("Chan");
		
//		Employee e4 = new Employee(111, "ABC", "DEF");
		
		//session.persist(e1);//persisting the object
		session.saveOrUpdate(e1);
		
		Employee e2=new Employee();
		e2.setId(102);
		e2.setFirstName("James");
		e2.setLastName("Ghosling");
		
		session.saveOrUpdate(e2);
		
		t.commit();//transaction is committed
		session.close();
		
		System.out.println("successfully saved");
		
	}
}
