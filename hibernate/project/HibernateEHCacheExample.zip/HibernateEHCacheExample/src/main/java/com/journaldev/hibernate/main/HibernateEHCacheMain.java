package com.journaldev.hibernate.main;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.stat.Statistics;

import com.journaldev.hibernate.model.Address;
import com.journaldev.hibernate.model.Employee;
import com.journaldev.hibernate.util.HibernateUtil;

public class HibernateEHCacheMain {

	public static void main(String[] args) {
		
		System.out.println("Temp Dir:"+System.getProperty("java.io.tmpdir"));
		
		//Initialize Sessions
		SessionFactory sessionFactory = HibernateUtil.getSessionFactory();
		Statistics stats = sessionFactory.getStatistics();
		System.out.println("Stats enabled="+stats.isStatisticsEnabled());
		stats.setStatisticsEnabled(true);
		System.out.println("Stats enabled="+stats.isStatisticsEnabled());
		
		/*Session s = sessionFactory.openSession();
		
		Transaction t = s.beginTransaction();
		Employee e1 = new Employee();
		e1.setName("John");
		e1.setSalary(1234.45);
		s.persist(e1);
		
		Address a1 = new Address();
		a1.setAddressLine1("100 Royal Drive");
		a1.setCity("Piscataway");
		a1.setZipcode("08854");
		a1.setEmployee(e1);
		s.persist(a1);
		
		Employee e2 = new Employee();
		e2.setName("Robin");
		e2.setSalary(3333.33);
		s.persist(e2);
				
		Address a2 = new Address();
		a2.setAddressLine1("200 Marine Drive");
		a2.setCity("Edison");
		a2.setZipcode("08820");
		a2.setEmployee(e2);
		s.persist(a2);
		
		Employee e3 = new Employee();
		e3.setName("Matt");
		e3.setSalary(4321.00);
		s.persist(e3);
		
		Address a3 = new Address();
		a3.setAddressLine1("One CPL");
		a3.setCity("Piscataway");
		a3.setZipcode("08854");
		a3.setEmployee(e3);
		s.persist(a3);
		
		t.commit();
		*/
		
		Session session = sessionFactory.openSession();
		Session otherSession = sessionFactory.openSession();
		Transaction transaction = session.beginTransaction();
		Transaction otherTransaction = otherSession.beginTransaction();
		
		printStats(stats, 0);
		
		
		
		Employee emp = (Employee) session.load(Employee.class, 8L);
		printData(emp, stats, 1);
		
		emp = (Employee) session.load(Employee.class, 8L);
		printData(emp, stats, 2);
		
		//clear first level cache, so that second level cache is used
		session.evict(emp);
		emp = (Employee) session.load(Employee.class, 8L);
		printData(emp, stats, 3);
		
		emp = (Employee) session.load(Employee.class, 10L);
		printData(emp, stats, 4);
		
		emp = (Employee) otherSession.load(Employee.class, 8L);
		printData(emp, stats, 5);
		
		//Release resources
		transaction.commit();
		otherTransaction.commit();
		sessionFactory.close();
	}

	private static void printStats(Statistics stats, int i) {
		System.out.println("***** " + i + " *****");
		System.out.println("Fetch Count="
				+ stats.getEntityFetchCount());
		System.out.println("Second Level Hit Count="
				+ stats.getSecondLevelCacheHitCount());
		System.out
				.println("Second Level Miss Count="
						+ stats
								.getSecondLevelCacheMissCount());
		System.out.println("Second Level Put Count="
				+ stats.getSecondLevelCachePutCount());
	}

	private static void printData(Employee emp, Statistics stats, int count) {
		System.out.println(count+":: Name="+emp.getName()+", Zipcode="+emp.getAddress().getZipcode());
		printStats(stats, count);
	}

}
